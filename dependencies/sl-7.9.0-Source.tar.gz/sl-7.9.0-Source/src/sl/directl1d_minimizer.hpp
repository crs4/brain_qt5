//+++HDR+++
//======================================================================
//  This file is part of the SL software library.
//
//  Copyright (C) 1993-2014 by Enrico Gobbetti (gobbetti@crs4.it)
//  Copyright (C) 1996-2014 by CRS4 Visual Computing Group, Pula, Italy
//
//  For more information, visit the CRS4 Visual Computing Group 
//  web pages at http://www.crs4.it/vvr/.
//
//  This file may be used under the terms of the GNU General Public
//  License as published by the Free Software Foundation and appearing
//  in the file LICENSE included in the packaging of this file.
//
//  CRS4 reserves all rights not expressly granted herein.
//  
//  This file is provided AS IS with NO WARRANTY OF ANY KIND, 
//  INCLUDING THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS 
//  FOR A PARTICULAR PURPOSE.
//
//======================================================================
//---HDR---//

/**
 * A streamlined version of the locally-biased DIRECT global optimization algorithm
 * for the univariate case 
 *
 * Jones, Donald R., Cary D. Perttunen, and Bruce E. Stuckman.
 * "Lipschitzian optimization without the Lipschitz constant."
 ° Journal of optimization Theory and Applications 79.1 (1993): 157-181.
 *
 * Jones, Donald R. "DIRECT global optimization algorithm."
 * Encyclopedia of optimization (2001): 431-440.
 *
 * Gablonsky, Joerg M., and Carl T. Kelley.
 * "A locally-biased form of the DIRECT algorithm."
 * Journal of Global Optimization 21.1 (2001): 27-37.
 *
 */

#pragma once

#include <sl/math.hpp>
#include <vector>
#include <set>
#include <iostream>

namespace sl {
  
  namespace detail {
    
    template <class T_FUNCTOR, class T_VALUE>
    class directl1d_minimizer_interval {
    public:
      typedef T_FUNCTOR functor_t;
      typedef T_VALUE   value_t;
    protected:
      std::size_t level_;
      value_t       f_c_;
      value_t       x_c_;
      value_t       width_;

    public:
      directl1d_minimizer_interval() {}
      
      directl1d_minimizer_interval(std::size_t l,
				   value_t f_c,
				   value_t x_c,
				   value_t w) :
	level_(l), f_c_(f_c), x_c_(x_c), width_(w) {
      }

    public: // Access

      inline std::size_t level() const { return level_; }
      inline value_t f_c() const { return f_c_; }
      inline value_t x_c() const { return x_c_; }
      inline value_t width() const { return width_; }
      inline value_t center_vertex_distance() const { return value_t(0.5)*width_; }
      
    public: // Sorting
      
      inline bool operator <(const directl1d_minimizer_interval& other) const {
	return f_c_ < other.f_c_;
      }

    public: // Trisecting
      
      directl1d_minimizer_interval left(const functor_t* f) const {
	directl1d_minimizer_interval result;
	result.level_ = level_ + 1;
	result.width_ = width_/value_t(3.0);
	result.x_c_   = x_c_-result.width_;
	result.f_c_   = (*f)(result.x_c_);
	return result;
      }
      
      directl1d_minimizer_interval right(const functor_t* f) const {
	directl1d_minimizer_interval result;
	result.level_ = level_ + 1;
	result.width_ = width_/value_t(3.0);
	result.x_c_   = x_c_+result.width_;
	result.f_c_   = (*f)(result.x_c_);
	return result;
      }
      
      directl1d_minimizer_interval center() const {
	directl1d_minimizer_interval result;
	result.level_ = level_ + 1;
	result.width_ = width_/value_t(3.0);
	result.x_c_   = x_c_;
	result.f_c_   = f_c_;
	return result;
      }
    };
  } // namespace detail

  /**
   * Global optimization in 1d using directl algorithm by Gablonski
   */
  template <class T_FUNCTOR, class T_VALUE>
  class directl1d_minimizer {
  public:
    typedef T_FUNCTOR functor_t;
    typedef T_VALUE   value_t;
    typedef detail::directl1d_minimizer_interval<functor_t,value_t> interval_t;
  protected:
    bool        is_verbose_;
    std::size_t max_fcall_count_;
    std::size_t max_iteration_count_;
    value_t relative_xtol_;
  protected:
    functor_t* f_;
    value_t      x_lo_;
    value_t      x_hi_;
  protected:
    value_t x_min_;
    value_t f_min_;
    
  public:
  
    inline directl1d_minimizer() :
      is_verbose_(false),
      max_fcall_count_(100),
      max_iteration_count_(100),
      relative_xtol_(1e-7f),
      f_(nullptr),
      x_lo_(value_t(0.0)),
      x_hi_(value_t(1.0)),
      x_min_(value_t(0.0)),
      f_min_(value_t(0.0)) {
    }

  public: // Function to be optimized
    
    inline void set_objective_functor(functor_t* f) {
      f_ = f;
    }
  
    inline void set_parameter_bounds(value_t x_lo, value_t x_hi) {
      x_lo_ = x_lo;
      x_hi_ = x_hi;
    }

    inline value_t x_lo() const {
      return x_lo_;
    }

    inline value_t x_hi() const {
      return x_hi_;
    }
    
  public: // Solver parameters
    
    inline bool is_verbose() const {
      return is_verbose_;
    }

    inline void set_is_verbose(bool x) {
      is_verbose_ = x;
    }
    
    inline std::size_t max_fcall_count() const {
      return max_fcall_count();
    }
  
    inline void set_max_fcall_count(std::size_t x) {
      max_fcall_count_ = x;
    }

    inline value_t relative_xtol(value_t x) const {
      return relative_xtol_;
    }

    inline void set_relative_xtol(value_t x) {
      relative_xtol_ = x;
    }
  
    inline std::size_t max_iteration_count() const {
      return max_iteration_count();
    }
  
    inline void set_max_iteration_count(std::size_t x) {
      max_iteration_count_ = x;
    }

    inline value_t last_x_best() const {
      return x_min_;
    }
    inline value_t last_f_best() const {
      return f_min_;
    }
  
    void minimize() {
      const value_t min_width = relative_xtol_*(x_hi_-x_lo_);
    
      intervals_init();

      std::size_t iteration_count=0;
      std::size_t fcall_count=1;
      x_min_ = value_t(0.5)*(x_lo_+x_hi_);
      f_min_ = (*f_)(x_min_);

      intervals_insert(interval_t(0,
				  f_min_,
				  x_min_,
				  (x_hi_-x_lo_)));
      bool converged = false;
      while (!converged) {
	// Extract lower right hull of the set of points (width, f_i)
	// The set contains, by construction, the set of potentially optimal
	// candidates (see Jones)
	std::vector<interval_t> lower_right_hull;
	intervals_extract_lower_right_hull_in(lower_right_hull);
	const std::size_t N_hull = lower_right_hull.size();
	
	// Subdivide promising candidates
	std::vector<bool> is_subdivided(N_hull, false);
	std::size_t subdivided_count = 0;
	std::size_t subdivision_trial=0;
	value_t largest_potentially_optimal_region_width = value_t(0.0);
	while (subdivided_count==0) {
	  for (std::size_t i=0; i<N_hull; ++i) {
	    bool subdivide = true;
	    if (subdivision_trial==1 && subdivided_count==0 && i==N_hull-1) {
	      // force subdivision of largest interval if we were unable to subdivide anything so far
	    } else  if (N_hull<4) {
	      // force subdivision if hull is small
	    } else {
	      // Check if estimated progress is "good enough". This is done by trying to
	      // estimate a proxy for the Lipschitz constant, that is the slope of the
	      // function f_min(width) that maintains the entire hull above the line passing
	      // through the current interval center. Given that value, we estimate the minimum
	      // possible value of the function within the current interval, and check if it
	      // is reasonably below the current best.
	      value_t K1=value_t(-1e30);
	      if (i>0)
		K1 = (lower_right_hull[i].f_c() - lower_right_hull[i-1].f_c()) / (lower_right_hull[i].center_vertex_distance() - lower_right_hull[i-1].center_vertex_distance());
	      value_t K2=value_t(-1e30);
	      if (i+1<N_hull)
		K2 = (lower_right_hull[i+1].f_c() - lower_right_hull[i].f_c()) / (lower_right_hull[i+1].center_vertex_distance() - lower_right_hull[i].center_vertex_distance());
	      value_t K=std::max(K1,K2);
	      K=std::max(value_t(1e-4),K); // FIXME don't trust too small K in flat areas
			 
	      value_t lower_bound = lower_right_hull[i].f_c() - K * lower_right_hull[i].center_vertex_distance();

	      //std::cerr << "K1=" << K1 << " K2=" << K2 << " K=" << K << std::endl;
	      value_t jones_eps = value_t(0.0);
	      if (subdivision_trial==0) {
		jones_eps = value_t(std::max(1e-4 * sl::abs(double(f_min_)), 1e-8));
	      }
	      subdivide = (lower_bound <= f_min_- jones_eps);
	    }
	    if (subdivide) {
	      largest_potentially_optimal_region_width = std::max(largest_potentially_optimal_region_width,
								  lower_right_hull[i].center_vertex_distance());
	      intervals_insert(lower_right_hull[i].left(f_)); ++fcall_count;
	      intervals_insert(lower_right_hull[i].center());
	      intervals_insert(lower_right_hull[i].right(f_)); ++ fcall_count;
	    
	      is_subdivided[i]=true;
	      ++subdivided_count;
	    } 
	  }
	  ++subdivision_trial;
	}
	++iteration_count;
      
	converged =
	  (largest_potentially_optimal_region_width<=min_width) ||
	  (fcall_count>=max_fcall_count_) ||
	  (iteration_count>=max_iteration_count_);

	if (!converged) {
	  // Reinsert all elements that were not subdivided
	  for (std::size_t i=0; i<N_hull; ++i) {
	    if (!is_subdivided[i]) intervals_insert(lower_right_hull[i]);
	  }
	}
	if (is_verbose()) {
	  std::cerr <<
	    "DIRECTL-1D[" << iteration_count << "]: " <<
	    "(fcall: " << fcall_count <<
	    " split: " << subdivided_count <<
	    " wmax: " << largest_potentially_optimal_region_width <<
	    ") => " <<
	    " x_min: " << x_min_ <<
	    " f_min: " << f_min_ <<
	    std::endl;
	}
      }

      // Cleanup
      intervals_clear();      
    }

  protected: // Intervals data structure and operations
    std::vector< std::set<interval_t> >  intervals_;

    void intervals_init() {
      intervals_.clear();
      intervals_.reserve(32);
    }

    void intervals_clear() {
      intervals_.clear();
    }
  
    void intervals_insert(const interval_t& box) {
      if (box.f_c() < f_min_) {
	f_min_ = box.f_c();
	x_min_ = box.x_c();
      }
      while (intervals_.size()<box.level()+1) {
	intervals_.push_back( std::set<interval_t>() );
      }
      intervals_[box.level()].insert(box);
    }

    // Cross product of OA and OB vectors
    value_t intervals_cross(std::size_t iO, std::size_t iA, std::size_t iB) const {
      const interval_t& O = *intervals_[iO].begin(); const value_t Ox = O.center_vertex_distance(); const value_t Oy = O.f_c();
      const interval_t& A = *intervals_[iA].begin(); const value_t Ax = A.center_vertex_distance(); const value_t Ay = A.f_c();
      const interval_t& B = *intervals_[iB].begin(); const value_t Bx = B.center_vertex_distance(); const value_t By = B.f_c();

      return (Ax - Ox) * (By - Oy) - (Ay - Oy) * (Bx - Ox);
    }

    bool intervals_is_ccw(std::size_t iO, std::size_t iA, std::size_t iB) const {
      return intervals_cross(iO, iA, iB) > value_t(0.0);
    }
  
    void intervals_lower_right_hull_in(std::vector<std::size_t>& lh) const {
      const std::size_t N_interval_widths = intervals_.size();
      
      std::vector<std::size_t> candidates;
      candidates.reserve(N_interval_widths);

      // Find all min rectangles per width, sorted by width
      std::size_t index_of_lower=0;
      value_t     lower_fvalue=value_t(1e30);
      for (std::size_t i=0; i<N_interval_widths; ++i) {
	std::size_t k=N_interval_widths-1-i;
	if (!intervals_[k].empty()) {
	  value_t fvalue = intervals_[k].begin()->f_c();
	  if (candidates.empty() || fvalue<lower_fvalue) {
	    index_of_lower=candidates.size();
	    lower_fvalue=fvalue;
	  }
	  candidates.push_back(k);
	}
      }

      // Remove all intervals to the left of the one containing the minimum function value
      //std::cerr << "LOWER: FVALUE=" << lower_fvalue << " IDX=" << index_of_lower << std::endl;
      if (index_of_lower!=0) {
	//std::cerr << "*************************** ERASING UP TO " << index_of_lower << std::endl;
	candidates.erase(candidates.begin(),
			 candidates.begin()+index_of_lower);
      }
    
      // Lower hull extraction using Andrew's monotone chain 2D convex hull algorithm
      // 2D coords are (width, value) for each interval (already sorted)
      // https://en.wikibooks.org/wiki/Algorithm_Implementation/Geometry/Convex_hull/Monotone_chain
      const std::size_t N_candidates = candidates.size();
      lh.clear();
      lh.reserve(N_candidates);
      for (std::size_t i = 0; i < N_candidates; ++i) {
	std::size_t k=candidates[i];
	while (lh.size() >= 2 && !intervals_is_ccw(lh[lh.size()-2], lh[lh.size()-1], k)) lh.pop_back();
	lh.push_back(k);
      }

#if 0
      std::cerr << "HULL: " << candidates.size() << " => " << lh.size() << std::endl;
      std::cerr << "=== CAND " << std::endl;
      for (std::size_t i=0; i< candidates.size(); ++i) {
	std::cerr << intervals_[candidates[i]].begin()->width() << "\t" << intervals_[candidates[i]].begin()->f_c() << std::endl;
      }
      std::cerr << "=== LOWER HULL " << std::endl;
      for (std::size_t i=0; i< lh.size(); ++i) {
	std::cerr << intervals_[lh[i]].begin()->width() << "\t" << intervals_[lh[i]].begin()->f_c() << std::endl;
      }
#endif
    }

    void intervals_extract_lower_right_hull_in(std::vector<interval_t>& lhi) {
      std::vector<std::size_t> lh;
      intervals_lower_right_hull_in(lh);
      const std::size_t N_hull = lh.size();
      lhi.clear();
      lhi.reserve(N_hull);
      for (std::size_t i=0; i<N_hull; ++i) {
	lhi.push_back(*intervals_[lh[i]].begin());
	intervals_[lh[i]].erase(intervals_[lh[i]].begin());
      }
    }
    
  };

} // namespace sl
