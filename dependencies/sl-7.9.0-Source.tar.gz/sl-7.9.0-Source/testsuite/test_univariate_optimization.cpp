//+++HDR+++
//======================================================================
//  This file is part of the SL software library.
//
//  Copyright (C) 1993-2014 by Enrico Gobbetti (gobbetti@crs4.it)
//  Copyright (C) 1996-2014 by CRS4 Visual Computing Group, Pula, Italy
//
//  For more information, visit the CRS4 Visual Computing Group 
//  web pages at http://www.crs4.it/vvr/.
//
//  This file may be used under the terms of the GNU General Public
//  License as published by the Free Software Foundation and appearing
//  in the file LICENSE included in the packaging of this file.
//
//  CRS4 reserves all rights not expressly granted herein.
//  
//  This file is provided AS IS with NO WARRANTY OF ANY KIND, 
//  INCLUDING THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS 
//  FOR A PARTICULAR PURPOSE.
//
//======================================================================
//---HDR---//
#include <sl/tester.hpp>
#include "sl/directl1d_minimizer.hpp"
#include <iostream>
#include <sstream>
#include <cstdio>
#include <cmath>

static std::size_t failed_test_count = 0;

// =================================================================
// TEST PROBLEMS
// http://infinity77.net/global_optimization/test_functions_1d.html
// =================================================================

class test_global_optimization {
  typedef double problem_functor(double x);
  
  std::vector<std::string> name_;
  std::vector<problem_functor*> f_;
  std::vector<double>      x_lo_;
  std::vector<double>      x_hi_;
  std::vector<double>      x_best_;
  std::vector<double>      f_best_;

  void push_problem(const std::string& name,
		    problem_functor* f,
		    double x_lo, double x_hi,
		    double x_best, double f_best) {
    name_.push_back(name);
    f_.push_back(f);
    x_lo_.push_back(x_lo); x_hi_.push_back(x_hi);
    x_best_.push_back(x_best); f_best_.push_back(f_best);

    double f_best_check = (*f)(x_best);
    if (std::abs(f_best_check-f_best)>1e-4) {
      std::cerr << "!!!!! (EEE) !!!! " << name << " f_best = " << f_best << " != f(x_best=" << x_best << ")=" << f_best_check << std::endl;
    }
  }

  void solve_all_problems() {
  }
  
public: // problem2
 
  static double p02_f(double x) {
    return std::sin(x)+std::sin(10.0f/3.0f*x);
  }

  static double p04_f(double x) {
    return -(16.0*x*x-24.0*x+5.0)*std::exp(-x);
  }

  static double p05_f(double x) {
    return -(1.4-3.0*x)*std::sin(18*x);
  }

  static double p06_f(double x) {
    return -(x+std::sin(x))*std::exp(-x*x);
  }

  static double p07_f(double x) {
    return std::sin(x)+std::sin(10.0/3.0*x)+std::log(x)-0.84*x+3.0;
  }

  static double p12_f(double x) {
    return std::pow(std::sin(x),3.0)+std::pow(std::cos(x),3.0);
  }

  void create_all_problems() {
    push_problem("PROBLEM02", &p02_f,
		 -2.7, 7.5,
		 5.145735, -1.899599);
    push_problem("PROBLEM04", &p04_f,
		 1.9, 3.9,
		 2.868034,-3.85045);
    push_problem("PROBLEM05", &p05_f,
		 0, 1.2,
		 0.96609, -1.48907);
    push_problem("PROBLEM06", &p06_f,
		 -10.0, 10.0,
		 0.67956, -0.824239);
    push_problem("PROBLEM07", &p07_f,
		 2.7, 7.5,
		 5.19978, -1.6013);
    push_problem("PROBLEM12", &p12_f,
		 2.0, 6.0,
		 3.14159265359, -1.0);
  }

public:
  
  void test() {
    sl::tester tester("directl1d_minimizer");

    create_all_problems();
    solve_all_problems();

    std::size_t problem_count = name_.size();
    for (std::size_t i=0; i<problem_count; ++i) {
      std::cerr << "============================================================================================" << std::endl;
      std::cerr << "Solving problem " << name_[i] << " in " << x_lo_[i] << " ..."  << x_hi_[i] << std::endl;
      std::cerr << "--------------------------------------------------------------------------------------------" << std::endl;

      sl::directl1d_minimizer<problem_functor, double> opt;
      opt.set_is_verbose(true);
      opt.set_max_fcall_count(50);
      opt.set_objective_functor(f_[i]);
      opt.set_parameter_bounds(x_lo_[i], x_hi_[i]);
      opt.minimize();
      std::cerr << "--------------------------------------------------------------------------------------------" << std::endl;
      std::cerr << "OPT: " <<
	opt.last_f_best()  << " = f(" << opt.last_x_best() << ") vs " <<
	f_best_[i]  << " = f(" << x_best_[i] << ")" <<
	"-- ABSERR: " << std::abs(f_best_[i]-opt.last_f_best()) << std::endl;
      std::cerr << "============================================================================================" << std::endl;
      tester.test(name_[i] + " minvalue", f_best_[i], sl::intervald(opt.last_f_best()-1e-4,opt.last_f_best()+1e-4));
    }

    failed_test_count += tester.failed_test_count();
  }
};

  
int main() {
  test_global_optimization p;
  p.test();
  return failed_test_count;
}
